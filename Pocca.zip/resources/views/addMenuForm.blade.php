@extends('layout')

@push('custom-js')
    <script src="https://code.jquery.com/jquery-3.6.4.js" integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E=" crossorigin="anonymous"></script>
    <script type="text/javascript" src="{{ asset ('js/imagePreviews.js') }}"></script>
@endpush

@section('content')
<div class="container py-3 h-100"> 
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col col-xl-10">
        <div class="d-flex justify-content-center mb-3 pb-1">
          <span class="h1 fw-bold">Add a new menu!</span>
        </div>

        <div class="card" style="border-radius: 1rem;">
          <div class="row g-0">
              <div class="card-body p-4 p-lg-5 text-black">
                <form method="POST" action="{{ url('/vendor-menu/add') }}" enctype="multipart/form-data">
                  @csrf

                  <div class="form-outline mb-4">
                    <label for="image" class="h5 fw-bold">Image</label>
                    <input class="form-control form-control-md @error('image') is-invalid @enderror" id="image" name="image" type="file">
        
                    @error('image')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror

                    <img id="preview-image" src="{{ asset('storage/payments/no-image.jpg') }}" alt="" class="img-thumbnail border-0 my-4 w-100" style="height: 300px; object-fit:contain;">
                  </div>

                  @php
                    $itemName = [''];
                    if (old('name')){
                      $itemName = explode('_',old('name'));
                    }
                  @endphp

                  <div class="form-outline mb-4">
                    <label for="name" class="h5 fw-bold">Name</label>
                    <input id="name" type="text" class="form-control form-control-md @error('name') is-invalid @enderror" name="name" value="{{ count($itemName) > 1 ? $itemName[1] : old('name') }}" autocomplete="name" placeholder="ex. Burger"/>

                    @error('name')
                      <span class="invalid-feedback" role="alert">
                          <strong>{{ $message }}</strong>
                      </span>
                    @enderror
                  </div>

                  <div class="form-outline mb-4">
                    <label for="description" class="h5 fw-bold">Description</label>
                    <textarea id="description" type="textbox" class="form-control form-control-md @error('description') is-invalid @enderror" name="description" autocomplete="description" placeholder="ex. Our signature burger" rows="3" style="resize:none;">{{ Request::old('description') }}</textarea>

                    @error('description')
                      <span class="invalid-feedback" role="alert">
                          <strong>{{ $message }}</strong>
                      </span>
                    @enderror
                  </div>

                  <div class="form-outline mb-4">
                    <label for="selectCategory" class="h5 fw-bold">Category</label>
                    <select class="form-select @error('selectCategory') is-invalid @enderror" id="selectCategory" name="selectCategory">
                      <option selected value="">Select category</option>
                      @foreach ($categories as $category)
                        @if (Request::old('selectCategory') == $category->id)
                            <option value="{{ $category->id }}" selected>{{ $category->name }}</option>
                        @else
                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                        @endif
                      @endforeach
                    </select>

                    @error('selectCategory')
                      <span class="invalid-feedback" role="alert">
                          <strong>{{ $message }}</strong>
                      </span>
                    @enderror
                  </div>

                  <div class="form-outline mb-4">
                    <label for="price" class="h5 fw-bold">Price</label>
                    <div class="input-group">
                        <span class="input-group-text">Rp.</span>
                        <input id="price" type="number" class="form-control form-control-md @error('price') is-invalid @enderror" name="price" value="{{ old('price') }}" autocomplete="price" placeholder="ex. 20000"/>
                    </div>

                    @error('price')
                        <span class="invalid-feedback d-block" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                  </div>

                  <div class="form-outline mb-4">
                    <label for="cook" class="h5 fw-bold">Cook Time</label>
                    <div class="input-group">
                        <input id="cook" type="number" class="form-control form-control-md @error('cook') is-invalid @enderror" name="cook" value="{{ old('cook') }}" autocomplete="cook" placeholder="ex. 200"/>
                        <span class="input-group-text">minutes</span>
                    </div>

                    @error('cook')
                          <span class="invalid-feedback d-block" role="alert">
                              <strong>{{ $message }}</strong>
                          </span>
                    @enderror
                  </div>

                  <div class="d-flex justify-content-center pt-1 mt-4">
                    <button class="btn btn-primary btn-md w-100" type="submit">Add</button>
                  </div>

                </form>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection
