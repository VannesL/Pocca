

<?php $__env->startPush('custom-js'); ?>
    <script src="https://code.jquery.com/jquery-3.6.4.js" integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E=" crossorigin="anonymous"></script>
    <script type="text/javascript" src="<?php echo e(asset ('js/imagePreviews.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-3 h-100"> 
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col col-xl-10">
        <div class="d-flex justify-content-center mb-3 pb-1">
            <span class="h1 fw-bold">Edit Menu</span>
        </div>
        <?php if(session()->has('Success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('Success')); ?>

            </div>
        <?php endif; ?>
        <div class="card" style="border-radius: 1rem;">
          <div class="row g-0">
              <div class="card-body p-4 p-lg-5 text-black">
                <form method="POST" action="/vendor-menu/edit/<?php echo e($item->id); ?>" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>

                  <div class="form-outline mb-4">
                    <label for="image" class="h5 fw-bold">Image</label>
                    <?php if($item->image != ''): ?>
                        <img id="preview-image" src="<?php echo e(asset('storage/menus/'.$item->image)); ?>" class="img-thumbnail border-0 mb-4 w-100" alt="image error" style="height: 300px; object-fit:contain;">
                    <?php else: ?>
                        <img id="preview-image" src="<?php echo e(asset('storage/menus/default.jpg')); ?>" class="img-thumbnail border-0 mb-4 w-100" alt="image error" style="height: 300px; object-fit:contain;">
                    <?php endif; ?>
                    <input class="form-control form-control-md <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="image" name="image" type="file">
        
                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <?php
                    $itemName = explode('_',$item->name)
                  ?>

                  <div class="form-outline mb-4">
                    <label for="name" class="h5 fw-bold">Name</label>
                    <input id="name" type="text" class="form-control form-control-md <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e($itemName[1]); ?>" autocomplete="name"/>

                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="form-outline mb-4">
                    <label for="description" class="h5 fw-bold">Description</label>
                    <textarea id="description" type="textbox" class="form-control form-control-md <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" autocomplete="description" style="resize:none;" rows="3"><?php echo e($item->description); ?></textarea>

                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="form-outline mb-4">
                    <label for="category" class="h5 fw-bold">Category</label>
                    <select class="form-select <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="category" name="category">
                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->category_id == $category->id): ?>
                            <option value="<?php echo e($category->id); ?>" selected><?php echo e($category->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="form-outline mb-4">
                    <label for="price" class="h5 fw-bold">Price</label>
                    <div class="input-group">
                        <span class="input-group-text">Rp.</span>
                        <input id="price" type="number" class="form-control form-control-md <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="price" value="<?php echo e($item->price); ?>" autocomplete="price"/>
                    </div>

                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="form-outline mb-4">
                    <label for="cook" class="h5 fw-bold">Cook Time</label>
                    <div class="input-group">
                        <input id="cook" type="number" class="form-control form-control-md <?php $__errorArgs = ['cook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cook" value="<?php echo e($item->cook_time); ?>" autocomplete="cook"/>
                        <span class="input-group-text">minutes</span>
                    </div>

                    <?php $__errorArgs = ['cook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="invalid-feedback d-block" role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="form-check mb-4">
                    <label for="availability" class="form-check-label h5 fw-bold">Availability</label>
                    <input id="availability" type="checkbox" class="form-check-input switch-input form-control-md" name="availability" value="1" <?php echo e(($item->availability ? 'checked' : '')); ?>/>
                  </div>

                  <div class="form-check mb-4">
                    <label for="recommended" class="form-check-label h5 fw-bold">Recommended</label>
                    <input id="recommended" type="checkbox" class="form-check-input switch-input form-control-md" name="recommended" value="1" <?php echo e(($item->recommended ? 'checked' : '')); ?>/>
                  </div>

                  <div class="buttons row d-flex justify-content-around pt-1 mt-4">
                    <div class="btn btn-danger col-3 m-2" data-bs-toggle="modal" data-bs-target="#deleteConfirmation">
                        <i class="fa-solid fa-trash-can"></i>
                    </div>
                    <button class="btn btn-primary btn-md w-100 col m-2" type="submit">Update</button>
                  </div>
                </form>

                <!-- Modal -->
                <div class="modal fade" id="deleteConfirmation" tabindex="-1" role="dialog" aria-hidden="true">
                  <div class="modal-dialog" style="" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="deleteConfirmationLabel">Are you sure?</h5>
                      </div>
                      <div class="modal-body">
                        This menu item will be deleted from the database.
                      </div>
                      <div class="modal-footer d-flex justify-content-around">
                        <div class="col-3"></div>
                        <form method="POST" action="/vendor-menu/delete/<?php echo e($item->id); ?>">
                          <?php echo csrf_field(); ?>
                          <button type ="submit" class="btn btn-danger col" data-bs-toggle="modal" data-bs-target="#deleteConfirmation">
                              Yes
                          </button>
                        </form>
                        <button type="button" class="btn btn-secondary col-6 me-1" data-bs-dismiss="modal">No</button> 
                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\Skripsi App\Pocca\resources\views/editMenuForm.blade.php ENDPATH**/ ?>