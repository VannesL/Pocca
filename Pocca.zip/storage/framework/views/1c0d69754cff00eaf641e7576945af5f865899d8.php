


<?php $__env->startSection('content'); ?>
<?php if(auth()->guard("vendor")->user()->upcoming_deletion_date != null): ?>
    <div class="container-fluid p-5" style="height:100vh">
        <p class="h1 text-center mt-5">Sorry your account is rejected by Admin because:</p>
        <p class="h1 text-center mt-5 alert alert-danger"><?php echo e(auth()->guard("vendor")->user()->rejection_reason); ?></p>
        
    </div>
<?php elseif(auth()->guard("vendor")->user()->approved_by == null): ?>
    <div class="container-fluid p-5" style="height:100vh">
        <p class="h1 text-center mt-5">Please wait for while Admin verify your account</p>
        
    </div>
<?php else: ?>
<div class="container-fluid  px-4">
    <div class="col">
        <div class="row"> 
            <div class="col-md-4  mb-3">
                <div class="card bg-success text-white">
                    <div class="card-body p-3">
                        <h5 class="mb-3" style="font-size: 12px">This Month Revenue</h5>
                        <h2 class="mb-3 text-break fw-bold" style="font-size: 23px">
                            <?php echo e(rupiah($revenueOrders[0]->revenue ?? '', true)); ?>

                        </h2>
                        <?php if($revDiff >=0): ?>
                        <h6 class="card-text font-weight-light" style="font-size: 12px" > Increase by <?php echo e($revDiff); ?>%</h6>
                        <?php else: ?>
                        <h6 class="card-text font-weight-light" style="font-size: 12px">Decrease by <?php echo e($revDiff); ?>%</h6>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="row">
                    <div class="col-6 mb-3">
                        <div class="card  bg-warning h-100">
                            <a class="text-white text-decoration-none" href="<?php echo e(url('/vendor-dash/reviews')); ?>">
                                <div class="card-body text-light p-3">
                                    <h5 class="mb-3" style="font-size: 15px">Rating</h5>
                                    <div class="mb-3 text-break fw-bold" style="font-size: 18px">
                                        <i class="fa-solid fa-star"></i>
                                        <?php echo e($rating); ?>

                                        <small>/ 5</small>
                                    </div>
                                    <h6 class="card-text font-weight-light" style="font-size: 12px">See review 
                                        <i class="fa-solid fa-angle-right" style="color: #ffffff;"></i>
                                    </h6>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-6 mb-3">
                        <div class="card  bg-info h-100">
                            <div class="card-body text-light p-3">
                                <h5 class="mb-3" style="font-size: 15px">This Month Orders</h5>
                                <h2 class="mb-3 text-break fw-bold" style="font-size: 18px">
                                    <i class="fa-solid fa-cart-shopping"></i> <?php echo e($revenueOrders[0]->total_order); ?>

                                </h2>
                                <?php if($ordDiff >=0): ?>
                                <h6 class="card-text font-weight-light " style="font-size: 12px"> Increase by <?php echo e($ordDiff); ?>% </h6>
                                <?php else: ?>
                                <h6 class="card-text font-weight-light" style="font-size: 12px">Decrease by <?php echo e($ordDiff); ?>%</h6>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row px-2"> 
            <h2 class="text-center mb-3">Sales Report</h2>
            <form action="<?php echo e(url('/vendor-dash')); ?>" method="GET" class="form-loading mb-3" style="padding: 0">
                <?php echo csrf_field(); ?>
                <div class="input-group <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <input name="selectedDate"  id="selectedDate" type="date" value="<?php echo e($selectedDate); ?>" class="form-control">
                    <button type="submit" class="btn btn-primary btn-block btn_submit ms-0 input-group-text"><i
                        class="fa fa-search"></i></button>
                </div>

            </form>
            <table class="table table-striped table-bordered " style="">
                <thead>
                  <tr>
                    <th class="col-1 text-center"scope="col">#</th>
                    <th class="col-5" scope="col">Menu</th>
                    <th class="col text-center" scope="col">Sold</th>
                    <th class="col-5 text-end"scope="col">Profits (Rp)</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $menuName = explode('_',$menu->name)
                        ?>
                        <tr>
                            <th class="text-center" scope="row"><?php echo e($loop->iteration); ?></th>
                            <td class="text-break"><?php echo e($menuName[1]); ?></td>
                            <td class="text-break text-center"><?php echo e($menu->sold); ?></td>
                            <td class="text-end"><?php echo e(rupiah($menu->profits ?? '')); ?></td>
                        </tr>
                       
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td  class="text-center fw-bold" colspan="2">Total Profits (Rp)</td>
                    <td class="text-end fw-bold" colspan="2"><?php echo e(rupiah($totalProfits ?? '')); ?></td>
                  </tr>
                </tbody>
              </table>
              
              
        </div>
    </div>
</div>
<link rel="stylesheet" href="<?php echo e(asset ('css/searchbar.css')); ?>">
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\Skripsi App\Pocca\resources\views/vendorDash.blade.php ENDPATH**/ ?>