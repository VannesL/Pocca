

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if($cartTotal > 0): ?>
            <div class="addBtn text-center position-fixed z-3" style="bottom:20px; right:20px;">
                <a href="<?php echo e(url('/customer-cart')); ?>" class="btn rounded btn-primary p-3">
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        <?php echo e($cartTotal); ?>

                        <span class="visually-hidden">number of items</span>
                    </span>
                    <i class="fa-solid fa-cart-shopping"></i>
                </a>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="row">
                        <div class="col-9">
                            <h5 class="card-title"><?php echo e($canteen->name); ?></h5>
                            <p class="card-text"><?php echo e($canteen->address); ?></p>
                        </div>
                        <?php if($canteen->favoritedCustomers->contains('id', $userId)): ?>
                            <div class="col-3 align-self-center">
                                <form action="<?php echo e(url('home/update-favorite-canteen', $canteen->id)); ?>" method="post"
                                    class="form-loading">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <input type="hidden" name="search" value="<?php echo e($search); ?>">
                                    <input type="hidden" name="favorite" value="0">
                                    <button type="submit" class="btn btn-block shadow-none"><i
                                            class="fa fa-heart fa-2xl"></i>
                                    </button>
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="col-3 align-self-center">
                                <form action="<?php echo e(url('home/update-favorite-canteen', $canteen->id)); ?>" method="post"
                                    class="form-loading">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <input type="hidden" name="search" value="<?php echo e($search); ?>">
                                    <input type="hidden" name="favorite" value="1">
                                    <button type="submit" class="btn btn-block shadow-none"><i
                                            class="fa fa-heart-o fa-2xl"></i>
                                    </button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </div><br>

                <form action="<?php echo e(url('/home', $canteen->id)); ?>" method="get" class="form-loading">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-4">
                            <div class="form-group <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <select name="type" id="" class="form-control">
                                    <option value="vendor" <?php echo e($type == 'vendor' ? 'selected' : ''); ?>>Vendor</option>
                                    <option value="menu_item" <?php echo e($type == 'menu_item' ? 'selected' : ''); ?>>Menu Item
                                    </option>
                                </select>
                                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <input name="search" type="text" value="<?php echo e($search); ?>" class="form-control"
                                    placeholder="Search">
                                <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-2 ps-1">
                            <button type="submit" class="btn btn-primary btn-block btn_submit ms-0"><i
                                    class="fa fa-search"></i></button>
                        </div>
                    </div>
                </form>
                <hr>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->favoritedCustomers->contains('id', $userId)): ?>
                        <a href="<?php echo e(url('/home/' . $item->canteen_id . '/' . $item->id)); ?>" class="text-decoration-none">
                            <div class="card mb-2">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-9">
                                            <h5 class="card-title"><?php echo e($item->name); ?></h5>
                                            <?php if($type == 'menu_item'): ?>
                                                <p class="card-text">
                                                    <?php $__currentLoopData = $item->menuItems->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $itemName = explode('_', $menuItem->name);
                                                        ?>
                                                        <?php echo e($itemName[1]); ?>,
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </p>
                                            <?php else: ?>
                                                <p class="card-text"><?php echo e($item->description); ?></p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-3 align-self-center">
                                            <form
                                                action="<?php echo e(url('home/' . $canteen->id . '/update-favorite-vendor/' . $item->id)); ?>"
                                                method="post" class="form-loading">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('put'); ?>
                                                <input type="hidden" name="search" value="<?php echo e($search); ?>">
                                                <input type="hidden" name="favorite" value="0">
                                                <button type="submit" class="btn btn-block shadow-none"><i
                                                        class="fa fa-heart fa-2xl"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$item->favoritedCustomers->contains('id', $userId)): ?>
                        <a href="<?php echo e(url('/home/' . $item->canteen_id . '/' . $item->id)); ?>" class="text-decoration-none">
                            <div class="card mb-2">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-9">
                                            <h5 class="card-title"><?php echo e($item->name); ?></h5>
                                            <?php if($type == 'menu_item'): ?>
                                                <p class="card-text">
                                                    <?php $__currentLoopData = $item->menuItems->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $itemName = explode('_', $menuItem->name);
                                                        ?>
                                                        <?php echo e($itemName[1]); ?>,
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </p>
                                            <?php else: ?>
                                                <p class="card-text"><?php echo e($item->description); ?></p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-3 align-self-center">
                                            <form
                                                action="<?php echo e(url('home/' . $canteen->id . '/update-favorite-vendor/' . $item->id)); ?>"
                                                method="post" class="form-loading">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('put'); ?>
                                                <input type="hidden" name="search" value="<?php echo e($search); ?>">
                                                <input type="hidden" name="favorite" value="1">
                                                <button type="submit" class="btn btn-block shadow-none"><i
                                                        class="fa fa-heart-o fa-2xl"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            $('i').click(function() {
                $(this).toggleClass('fa-heart fa-heart-o');
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\Skripsi App\Pocca\resources\views/Customer/canteen.blade.php ENDPATH**/ ?>