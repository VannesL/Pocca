

<?php $__env->startSection('content'); ?>
    <div class="container mt-1">
        <?php if($cartTotal > 0): ?>    
            <div class="addBtn text-center position-fixed z-3" style="bottom:20px; right:20px;">
                <a href="<?php echo e(url('/customer-cart')); ?>" class="btn rounded btn-primary p-3">
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        <?php echo e($cartTotal); ?>

                        <span class="visually-hidden">number of items</span>
                    </span>
                    <i class="fa-solid fa-cart-shopping"></i>
                </a>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-lg-12">
                <form action="<?php echo e(url('/home')); ?>" method="get" class="form-loading">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <select name="type" id="" class="input-group-text px-1 text-center">
                            <option value="canteen" <?php echo e($type == 'canteen' ? 'selected' : ''); ?>>Canteen</option>
                            <option value="vendor" <?php echo e($type == 'vendor' ? 'selected' : ''); ?>>Vendor</option>
                        </select>
                        <input name="search" type="text" value="<?php echo e($search); ?>" class="form-control"placeholder="Search" id="search">
                        <button type="submit" class="btn btn-primary btn-block btn_submit ms-0 input-group-text"><i class="fa fa-search"></i></button>
                    </div>
                </form>
                <hr>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->favoritedCustomers->contains('id', $userId)): ?>
                        <a href="<?php echo e(url('/home/' . $item->id)); ?>" class="text-decoration-none">
                            <div class="card mb-2">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-9">
                                            <h5 class="card-title"><?php echo e($item->name); ?></h5>
                                            <p class="card-text"><?php echo e($item->address); ?></p>
                                        </div>
                                        <div class="col-3 align-self-center">
                                            <form action="<?php echo e(url('home/update-favorite-canteen/' . $item->id)); ?>"
                                                method="post" class="form-loading">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('put'); ?>
                                                <input type="hidden" name="search" value="<?php echo e($search); ?>">
                                                <input type="hidden" name="favorite" value="0">
                                                <button type="submit" class="btn btn-block shadow-none"><i
                                                        class="fa fa-heart fa-2xl"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <?php if($type == 'vendor'): ?>
                                    <ol class="list-group list-group-flush">
                                        <?php $__currentLoopData = $item->vendors->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item bg-light">
                                                <div class="row d-flex flex-row justify-content-between mb-1">
                                                    <div class="col-5 fw-semibold">
                                                        <?php echo e($vendor->store_name); ?>

                                                    </div>
                                                    <div class="col-4 text-center">
                                                        <?php if($vendor->priceRange): ?>
                                                            <?php echo e($vendor->priceRange->value); ?>

                                                        <?php else: ?>
                                                            N/A
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="col-3 text-center">
                                                        <?php if($vendor->avg_rating ): ?>
                                                            <?php echo e($vendor->avg_rating); ?> <i class="fa-solid fa-star me-1"></i>
                                                        <?php else: ?>
                                                            N/A
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="text-truncate" style="font-size: 0.875em; max-width:100%">
                                                    <?php echo e($vendor->description); ?>

                                                </div>
                                            </li> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>
                                <?php endif; ?>
                            </div>
                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$item->favoritedCustomers->contains('id', $userId)): ?>
                        <?php if($type == 'vendor' && $item->vendors->isEmpty()): ?>
                        <?php else: ?>
                            <a href="<?php echo e(url('/home/' . $item->id)); ?>" class="text-decoration-none">
                                <div class="card mb-2">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-9">
                                                <h5 class="card-title"><?php echo e($item->name); ?></h5>
                                                <p class="card-text"><?php echo e($item->address); ?></p>
                                            </div>
                                            <div class="col-3 align-self-center">
                                                <form action="<?php echo e(url('home/update-favorite-canteen/' . $item->id)); ?>" method="post" class="form-loading">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('put'); ?>
                                                    <input type="hidden" name="search" value="<?php echo e($search); ?>">
                                                    <input type="hidden" name="favorite" value="1">
                                                    <button type="submit" class="btn btn-block shadow-none"><i
                                                            class="fa fa-heart-o fa-2xl"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if($type == 'vendor'): ?>
                                        <ol class="list-group list-group-flush">
                                            <?php $__currentLoopData = $item->vendors->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="list-group-item bg-light">
                                                    <div class="row d-flex flex-row justify-content-between mb-1">
                                                        <div class="col-5 fw-semibold">
                                                            <?php echo e($vendor->store_name); ?>

                                                        </div>
                                                        <div class="col-4 text-center">
                                                            <?php if($vendor->priceRange): ?>
                                                                <?php echo e($vendor->priceRange->value); ?>

                                                            <?php else: ?>
                                                                N/A
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="col-3 text-center">
                                                            <?php if($vendor->avg_rating ): ?>
                                                                <?php echo e($vendor->avg_rating); ?> <i class="fa-solid fa-star me-1"></i>
                                                            <?php else: ?>
                                                                N/A
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="text-truncate" style="font-size: 0.875em; max-width:100%">
                                                        <?php echo e($vendor->description); ?>

                                                    </div>
                                                </li> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ol>
                                    <?php endif; ?>
                                </div>
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<link rel="stylesheet" href="<?php echo e(asset ('css/searchbar.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\Skripsi App\Pocca\resources\views/Customer/customerHome.blade.php ENDPATH**/ ?>