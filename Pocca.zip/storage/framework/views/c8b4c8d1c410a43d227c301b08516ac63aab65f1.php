

<?php $__env->startSection('content'); ?>
    <div class="container mt-1">
        <?php if($cartTotal > 0): ?>
            <div class="addBtn text-center position-fixed z-3" style="bottom:20px; right:20px;">
                <a href="<?php echo e(url('/customer-cart')); ?>" class="btn rounded btn-primary p-3">
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        <?php echo e($cartTotal); ?>

                        <span class="visually-hidden">number of items</span>
                    </span>
                    <i class="fa-solid fa-cart-shopping"></i>
                </a>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0">
                    <div class="row">
                        <div class="col-9">
                            <h5 class="card-title"><?php echo e($canteen->name); ?></h5>
                            <p class="card-text"><?php echo e($canteen->address); ?></p>
                        </div>
                        <?php if($canteen->favoritedCustomers->contains('id', $userId)): ?>
                            <div class="col-3 align-self-center">
                                <form action="<?php echo e(url('home/update-favorite-canteen', $canteen->id)); ?>" method="post"
                                    class="form-loading">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <input type="hidden" name="search" value="<?php echo e($search); ?>">
                                    <input type="hidden" name="favorite" value="0">
                                    <button type="submit" class="btn btn-block shadow-none"><i
                                            class="fa fa-heart fa-2xl"></i>
                                    </button>
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="col-3 align-self-center">
                                <form action="<?php echo e(url('home/update-favorite-canteen', $canteen->id)); ?>" method="post"
                                    class="form-loading">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <input type="hidden" name="search" value="<?php echo e($search); ?>">
                                    <input type="hidden" name="favorite" value="1">
                                    <button type="submit" class="btn btn-block shadow-none"><i
                                            class="fa fa-heart-o fa-2xl"></i>
                                    </button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </div><br>


                <form action="<?php echo e(url('/home', $canteen->id)); ?>" method="get" class="form-loading">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <select name="type" id="" class="input-group-text px-1">
                            <option value="vendor" <?php echo e($type == 'vendor' ? 'selected' : ''); ?>>Vendor</option>
                            <option value="menu_item" <?php echo e($type == 'menu_item' ? 'selected' : ''); ?>>Menu</option>
                        </select>
                        <input name="search" type="text" value="<?php echo e($search); ?>" class="form-control"placeholder="Search" id="search">
                        <button type="submit" class="btn btn-primary btn-block btn_submit ms-0 input-group-text"><i class="fa fa-search"></i></button>
                    </div>       
                </form>
                <hr>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->favoritedCustomers->contains('id', $userId)): ?>
                        <?php if($type == 'menu_item' && $item->menuItems->count()<1): ?>
                            
                        <?php else: ?>    
                            <a href="<?php echo e(url('/home/' . $item->canteen_id . '/' . $item->id)); ?>" class="text-decoration-none">
                            <div class="card mb-2">
                                <div class="card-body py-2">
                                    <div class="row">
                                        <div class="col p-0 text-center">
                                            <img class="card-img" src="<?php echo e(asset('storage/profiles/' . $item->image)); ?>" alt="no image" style="height: 100px; width:100px; object-fit:cover;">
                                        </div>
                                        <div class="col-6 px-2">
                                            <h6 class="card-title"><?php echo e($item->store_name); ?></h6>                  
                                            <div class="container px-0 card-text" style="font-size: 0.875em;">
                                                <div style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;"><?php echo e($item->description); ?></div>
                                                <div class="d-flex mt-2 text-start justify-content-between">
                                                    <div class="">
                                                        <?php if($item->avg_rating): ?>
                                                            <?php echo e($item->avg_rating); ?> <i class="fa-solid fa-star me-1"></i>
                                                        <?php else: ?>
                                                            N/A
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="">
                                                        <?php if($item->priceRange): ?>
                                                            <?php echo e($item->priceRange->value); ?>

                                                        <?php else: ?>
                                                            N/A
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-2 align-self-center text-center p-0">
                                            <form
                                                action="<?php echo e(url('home/' . $canteen->id . '/update-favorite-vendor/' . $item->id)); ?>"
                                                method="post" class="form-loading">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('put'); ?>
                                                <input type="hidden" name="search" value="<?php echo e($search); ?>">
                                                <input type="hidden" name="favorite" value="0">
                                                <button type="submit" class="btn btn-block shadow-none"><i
                                                        class="fa fa-heart fa-2xl"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <?php if($type == 'menu_item'): ?>
                                    <ol class="list-group list-group-flush">
                                        <?php $__currentLoopData = $item->menuItems->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $menuName = explode('_', $menu->name);
                                            ?>
                                            <li class="list-group-item d-flex justify-content-between bg-light">
                                                <div class="col fw-semibold">
                                                    <?php echo e($menuName[1]); ?>

                                                </div>
                                                <div class="col text-center fw-medium">
                                                    <small class="fw-normal">Rp. </small><?php echo e($menu->price); ?>

                                                </div>
                                            </li> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>
                                <?php endif; ?>
                            </div>
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$item->favoritedCustomers->contains('id', $userId)): ?>
                        <?php if($type == 'menu_item' && $item->menuItems->count()<1): ?>
                        <?php else: ?>
                            <a href="<?php echo e(url('/home/' . $item->canteen_id . '/' . $item->id)); ?>" class="text-decoration-none">
                                <div class="card mb-2">
                                    <div class="card-body py-2">
                                        <div class="row">
                                            <div class="col p-0 text-center">
                                                <img class="card-img" src="<?php echo e(asset('storage/profiles/' . $item->image)); ?>" alt="no image" style="height: 100px; width:100px; object-fit:cover;">
                                            </div>
                                            <div class="col-6 px-2">
                                                <h6 class="card-title"><?php echo e($item->store_name); ?></h6>                  
                                                <div class="container px-0 card-text " style="font-size: 0.875em;">
                                                    <div style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;"><?php echo e($item->description); ?></div>
                                                    <div class="d-flex mt-2 text-start justify-content-between">
                                                        <div class="">
                                                            <?php if($item->avg_rating): ?>
                                                                <?php echo e($item->avg_rating); ?> <i class="fa-solid fa-star me-1"></i>
                                                            <?php else: ?>
                                                                N/A
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="">
                                                            <?php if($item->priceRange): ?>
                                                                <?php echo e($item->priceRange->value); ?>

                                                            <?php else: ?>
                                                                N/A
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-2 align-self-center text-center p-0">
                                                <form
                                                    action="<?php echo e(url('home/' . $canteen->id . '/update-favorite-vendor/' . $item->id)); ?>"
                                                    method="post" class="form-loading">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('put'); ?>
                                                    <input type="hidden" name="search" value="<?php echo e($search); ?>">
                                                    <input type="hidden" name="favorite" value="1">
                                                    <button type="submit" class="btn btn-block shadow-none"><i
                                                            class="fa fa-heart-o fa-2xl"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if($type == 'menu_item'): ?>
                                        <ol class="list-group list-group-flush">
                                            <?php $__currentLoopData = $item->menuItems->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $menuName = explode('_', $menu->name);
                                                ?>
                                                <li class="list-group-item d-flex justify-content-between bg-light">
                                                    <div class="col fw-semibold">
                                                        <?php echo e($menuName[1]); ?>

                                                    </div>
                                                    <div class="col text-center fw-medium">
                                                        <small class="fw-normal">Rp. </small><?php echo e($menu->price); ?>

                                                    </div>
                                                </li> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ol>
                                    <?php endif; ?>
                                </div>
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<link rel="stylesheet" href="<?php echo e(asset ('css/searchbar.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            $('i').click(function() {
                $(this).toggleClass('fa-heart fa-heart-o');
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\Skripsi App\Pocca\resources\views/Customer/customerCanteenView.blade.php ENDPATH**/ ?>