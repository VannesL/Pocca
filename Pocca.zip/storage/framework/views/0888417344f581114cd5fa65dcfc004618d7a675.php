

<?php $__env->startPush('custom-js'); ?>
    <script src="https://code.jquery.com/jquery-3.6.4.js" integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E="
        crossorigin="anonymous"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/inputNumberWithButton.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset ('css/searchbar.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $cartTotal = 0;
        foreach ($cartItems as $cartItem) {
            $cartTotal = $cartTotal + $cartItem->quantity;
        }
    ?>
    <?php if($cartTotal > 0): ?>
        <div class="addBtn text-center position-fixed z-3" style="bottom:20px; right:20px;">
            <a href="<?php echo e(url('/customer-cart')); ?>" class="btn rounded btn-primary p-3">
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    <?php echo e($cartTotal); ?>

                    <span class="visually-hidden">number of items</span>
                </span>
                <i class="fa-solid fa-cart-shopping"></i>
            </a>
        </div>
    <?php endif; ?>
    <div class="container position-relative">
        
        <div class="container mb-4 text-light rounded"
            style="background-image: url(<?php echo e(asset('storage/profiles/' . $vendor->image)); ?>); background-size: cover;  background-position: center">
            <div class="row rounded p-3" style="background-color: rgba(0, 0, 0, 0.603); backdrop-filter: blur(1px);">
                <div class="col-9">
                    <div class="row">
                        <h4><?php echo e($vendor->store_name); ?></h4>
                    </div>
                    <div class="row">
                        <p><?php echo e($vendor->description); ?></p>
                    </div>
                    <div class="row fs-6">
                        <div class="col-5 fw-bold">
                            <i class="fa-solid fa-star me-1"></i>
                            <?php echo e($vendor->avg_rating); ?>

                            <small class="fw-light">/ 5</small>
                        </div>
                        <div class="col-7 fw-bold">
                            <?php if($vendor->priceRange): ?>
                                <small class="fw-light">Rp.</small> <?php echo e($vendor->priceRange->value); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <?php if($vendor->favoritedCustomers->contains('id', $userId)): ?>
                    <div class="col-3 align-self-center">
                        <form action="<?php echo e(url('home/'.$vendor->canteen_id.'/update-favorite-vendor/'.$vendor->id)); ?>" method="post"
                            class="form-loading">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="search" value="<?php echo e($search); ?>">
                            <input type="hidden" name="favorite" value="0">
                            <button type="submit" class="btn btn-block shadow-none"><i class="fa fa-heart fa-2xl" style="color: white"></i>
                            </button>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="col-3 align-self-center">
                        <form action="<?php echo e(url('home/'.$vendor->canteen_id.'/update-favorite-vendor/'.$vendor->id)); ?>" method="post"
                            class="form-loading">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="search" value="<?php echo e($search); ?>">
                            <input type="hidden" name="favorite" value="1">
                            <button type="submit" class="btn btn-block shadow-none"><i class="fa fa-heart-o fa-2xl" style="color: white"></i>
                            </button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <form action="<?php echo e(url('/home/'. $vendor->canteen->id.'/'.$vendor->id)); ?>" method="get" class="form-loading mb-3">
            <?php echo csrf_field(); ?>
            <div class="input-group <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <input name="search" type="text" value="<?php echo e($search); ?>" class="form-control"
                            placeholder="Search" id="search">
                            <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="form-text m-b-none text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <button type="submit" class="btn btn-primary btn-block btn_submit input-group-text"><i
                            class="fa fa-search"></i></button>
            </div>
        </form>
        <div class="row px-3">
        <?php if(!$categories->isEmpty()): ?>
            <?php $__currentLoopData = $menuByCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion accordion-flush mb-4" id="accordion<?php echo e($loop->index); ?>">
                    <div class="accordion-item ">
                        <h2 class="accordion-header">
                            <button class="accordion-button fw-bold" type="button" data-bs-toggle="collapse"
                                data-bs-target="#<?php echo e($categories[$loop->index]->category_name); ?>" aria-expanded="true"
                                aria-controls="collapseOne">
                                <?php echo e($categories[$loop->index]->category_name); ?>

                            </button>
                        </h2>
                        <div id="<?php echo e($categories[$loop->index]->category_name); ?>" class="accordion-collapse collapse show "
                            data-bs-parent="#accordion<?php echo e($loop->index); ?>">
                            <div class="accordion-body row">
                                <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $itemName = explode('_', $item->name);

                                        $cartItemId = null;
                                        $notes = null;
                                        $quantity = 0;
                                        if ($cartItems) {
                                            foreach ($cartItems as $cartItem) {
                                                if ($item->id == $cartItem->menu_id) {
                                                    $cartItemId = $cartItem->id;
                                                    $quantity = $cartItem->quantity;
                                                    if ($notes !== '') {
                                                        $notes = $cartItem->notes;
                                                    }
                                                }
                                            }
                                        }
                                    ?>
                                    <?php if($loop->index % 2 == 0): ?>
                                        <div class="col-md-4">
                                            <div class="row h-100">
                                    <?php endif; ?>

                                    <div class="col-6 p-1">
                                        <?php if($item->availability): ?>
                                            <a class="text-decoration-none" data-bs-toggle="modal"
                                                data-bs-target="#<?php echo e($item->id); ?>addToCart" href="">
                                        <?php endif; ?>
                                        <div class="card  text-center h-100 border-white <?php echo e($item->availability ? '' : 'opacity-25'); ?>"
                                            style="box-shadow: 0px 2px 10px 2px #8b9ce936;">
                                            <?php if($item->recommended): ?>
                                                <span
                                                    class="z-2 d-flex position-absolute translate-middle badge rounded-pill bg-warning text-center align-items-center"
                                                    style="width:30px; height:30px; left:95%; top:5%;vertical-align: middle">
                                                    <i class="fa-solid fa-thumbs-up fa-lg" style="color: #ffffff;"></i>
                                                </span>
                                            <?php endif; ?>
                                            <?php if($item->image != ''): ?>
                                                <img src="<?php echo e(asset('storage/menus/' . $item->image)); ?>"
                                                    class="card-img-top img-thumbnail p-2 border-0 <?php if(!$item->availability): ?> opacity-50 <?php endif; ?>"
                                                    alt="image error" style="height: 120px; object-fit:cover;">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('storage/menus/default.jpg')); ?>"
                                                    class="card-img-top img-thumbnail p-2 border-0 <?php if(!$item->availability): ?> opacity-50 <?php endif; ?>"
                                                    alt="image error" style="height: 120px; object-fit:cover;">
                                            <?php endif; ?>
                                            <div class="card-body">
                                                <div class="row h-75">
                                                    <h6 class="card-title "><?php echo e($itemName[1]); ?></h6>
                                                </div>
                                                <div class="row h-25">
                                                    <p class="card-text"><?php echo e(rupiah($item->price ?? '', true)); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if($item->availability): ?>
                                            </a>
                                            <!-- Modal -->
                                            <div class="modal fade" id="<?php echo e($item->id); ?>addToCart" tabindex="-1"
                                                aria-hidden="true">
                                                <div class="z-3 modal-dialog position-absolute mb-0 start-0 end-0 bottom-0 "
                                                    style="max-height: 90%">

                                                    <div class="modal-content" style="">
                                                        <div class="container">
                                                            <div class="row">
                                                                <a class="btn btn-plus rounded-0 btn-danger"
                                                                    data-bs-dismiss="modal">
                                                                    <i class="fa-solid fa-times"></i>
                                                                </a>
                                                            </div>
                                                        </div>

                                                        <div class="modal-header">
                                                            <?php if($item->image != ''): ?>
                                                                <img src="<?php echo e(asset('storage/menus/' . $item->image)); ?>"
                                                                    class="card-img-top img-thumbnail p-2 border-0 "
                                                                    alt="image error" style="height: 300px; object-fit:cover;">
                                                            <?php else: ?>
                                                                <img src="<?php echo e(asset('storage/menus/default.jpg')); ?>"
                                                                    class="card-img-top img-thumbnail p-2 border-0"
                                                                    alt="image error" style="height: 300px; object-fit:cover;">
                                                            <?php endif; ?>
                                                        </div>

                                                        <div class="modal-body">
                                                            <div class="container">
                                                                <div class="row px-2">
                                                                    <div class="col-8">
                                                                        <h5 class="text-break"><?php echo e($itemName[1]); ?></h5>

                                                                    </div>
                                                                    <div class="col-4 text-end fw-medium">
                                                                        <p> <i class="fa-solid fa-hourglass-end me-1"></i>
                                                                            <?php echo e($item->cook_time); ?> <span
                                                                                class="">min</span></p>

                                                                    </div>
                                                                </div>
                                                                <div class="row px-3">
                                                                    <p><?php echo e($item->description); ?></p>
                                                                </div>
                                                                <div
                                                                    class="row px-3 d-flex align-items-center flex-column">
                                                                    <form
                                                                        action="<?php echo e(url('/vendor/' . $vendor->id . '/addToCart/' . $item->id)); ?>"
                                                                        method="post" class="form-loading mb-3">
                                                                        <?php echo csrf_field(); ?>
                                                                        <div class="mb-3">
                                                                            <label for="notes"
                                                                                class="form-label fw-medium">Notes</label>
                                                                            <textarea class="form-control" id="notes" name='notes' rows="3" placeholder="ex. Make it good!"><?php echo e($notes ? $notes : ''); ?></textarea>
                                                                        </div>
                                                                        <div
                                                                            class="row mb-4 d-flex align-items-center justify-content-between">
                                                                            <div class="col-6 fw-medium h4 mb-0">
                                                                                <?php echo e(rupiah($item->price ?? '', true)); ?>

                                                                            </div>
                                                                            <div class="col-6">
                                                                                <div class="input-group inline-group">
                                                                                    <div class="input-group-prepend">
                                                                                        <a
                                                                                            class="btn btn-minus rounded-circle btn-outline-dark">
                                                                                            <i
                                                                                                class="fa fa-minus fa-sm"></i>
                                                                                        </a>
                                                                                    </div>
                                                                                    <input
                                                                                        class="form-control quantity text-center border-0"
                                                                                        min="1" max="99"
                                                                                        name="quantity"
                                                                                        value=<?php echo e($quantity !== 0 ? $quantity : '1'); ?>

                                                                                        type="number">
                                                                                    <div class="input-group-append">
                                                                                        <a
                                                                                            class="btn btn-plus rounded-circle btn-outline-dark">
                                                                                            <i
                                                                                                class="fa fa-plus fa-sm"></i>
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="row">
                                                                            <?php if($quantity > 0): ?>
                                                                                <div class="d-flex justify-content-around">
                                                                                    <a href="<?php echo e(url('/remove-item/' . $cartItemId)); ?>"
                                                                                        class="btn btn-danger w-50 me-1">Remove
                                                                                        Item</a>
                                                                                    <button
                                                                                        class="btn btn-primary w-50 ms-1"
                                                                                        type="submit">Update Item</button>
                                                                                </div>
                                                                            <?php else: ?>
                                                                                <button class="btn btn-primary w-100"
                                                                                    type="submit">Add Item</button>
                                                                            <?php endif; ?>

                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        </a>
                                    </div>

                                    <?php if($loop->index % 2 != 0 || $loop->last): ?>
                            </div>
                        </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <h3 class="col p-5 text-center">Sorry the menu for this vendor is currently not available.</h3>
    <?php endif; ?>
    </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\Skripsi App\Pocca\resources\views/Customer/customerMenu.blade.php ENDPATH**/ ?>