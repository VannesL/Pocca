

<?php $__env->startPush('custom-js'); ?>
  <script type="text/javascript" src="<?php echo e(asset ('js/refreshOrderDetails.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3 class="">Order for: <?php echo e($order->customer->name); ?></h3>
        <h6 class="mb-3"><?php echo e($order->customer->phone_number); ?></h6>

        <?php
            $color = "";

            switch ($order->status->id) {
            case 1:
                $color = "secondary";
                break;
            case 2:
                $color = "warning";
                break;
            case 3:
                $color = "primary";
                break;
            case 4:
                $color = "success";
                break;
            case 5:
                $color = "dark";
                break;
            }
        ?>
        <div class="d-flex justify-content-between mb-2">
            <div id="orderStatus" class="text-bg-<?php echo e($color); ?> text-center fs-3 fw-bold px-2">
                <?php echo e($order->status->name); ?>

            </div> 
            <div>
                <?php if($order->type): ?>
                    <div class="mt-2">Eat-In</div>
                <?php else: ?>
                    <div class="mt-2">Takeout</div>
                <?php endif; ?>   
            </div>
        </div>
            

        <div class="container p-2 border border-dark bg-light">
            <div class="header d-flex justify-content-between px-2 pt-2">
                <div>OrderId: <?php echo e($order->id); ?></div>
                <div class="align-items-end"><?php echo e($order->date); ?></div>
            </div>
            <hr>
            <table class="table table-borderless">
                <tbody>
                    <?php $__currentLoopData = $orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $itemName = explode('_',$orderItem->menu->name);
                        $price = $orderItem->quantity * $orderItem->menu->price;
                    ?>
                    <tr class="border-end-0">
                        <td class="col-md-1"><?php echo e($orderItem->quantity); ?>x</td>
                        <td class="col-md-9"><?php echo e($itemName[1]); ?></td>
                        <td class="col-md-2">Rp. <?php echo e($price); ?></td>
                    </tr>
                    <?php if($orderItem->notes != ''): ?>
                        <tr>
                            <td class="col-md-1"></td>
                            <td class="col-md-9 fst-italic pt-0"><?php echo e($orderItem->notes); ?></td>
                        </tr>
                    <?php endif; ?>              
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <hr>
            <div class="footer d-flex justify-content-between px-2">
                <div>Total:</div>
                <div class="h4">Rp. <?php echo e($order->total); ?></div>
            </div>
        </div>

        <div class=" container d-flex mt-3 h-100 flex-column">
            <?php if($order->payment_image != ''): ?>
                <img id = "paymentImg" src="<?php echo e(asset('storage/payments/'.$order->payment_image)); ?>" class="img-thumbnail border-0 mb-4 w-100" alt="image error" style="height: 250px; object-fit:contain;" data-bs-toggle="modal" data-bs-target="#imgPreview">
                <!-- Modal -->
                <div class="modal fade bg-transparent" id="imgPreview" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered bg-transparent" style="" role="document">
                        <div class="modal-body bg-transparent">
                            <img id = "paymentImg" src="<?php echo e(asset('storage/payments/'.$order->payment_image)); ?>" class="img-thumbnail border-0 mb-4 w-100 h-100" alt="image error" style="object-fit:contain;">
                        </div>
                    </div> 
                </div>
            <?php endif; ?>

            <?php switch($order->status->id):
                case (1): ?>
                    <div class="fw-bold text-center">Waiting for customer to complete payment...</div>
                    <?php break; ?>
                <?php case (2): ?>
                    <div class="d-flex justify-content-around fw-bold w-75 mx-auto">
                        <a href="/delete-order" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteConfirmation">Reject</a>
                        <a href="/order/vendor/update-status/<?php echo e($order->id); ?>" class="btn btn-primary">Approve</a>
                    </div>
                    <!-- Modal -->
                    <div class="modal fade" id="deleteConfirmation" tabindex="-1" role="dialog" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered" style="" role="document">
                        <form method="POST" action="/order/vendor/delete/<?php echo e($order->id); ?>" class="modal-content">
                            <?php echo csrf_field(); ?>
                            <div class="modal-header">
                            <h5 class="modal-title" id="deleteConfirmationLabel">Please enter rejection reason:</h5>
                            </div>
                            <div class="modal-body">
                                <div class="form-outline">
                                    <textarea id="reason" type="textbox" class="form-control form-control-md" name="reason" placeholder="ex. Fake payment" rows="3" style="resize:none;"></textarea>
                                </div>
                            </div>
                            <div class="modal-footer d-flex justify-content-around">  
                                <button type ="submit" class="btn btn-danger col" data-bs-toggle="modal" data-bs-target="#deleteConfirmation">
                                    Submit
                                </button>
                                <button type="button" class="btn btn-secondary col-6 me-1" data-bs-dismiss="modal">Cancel</button> 
                            </div>
                        </form>
                        </div> 
                    </div>                
                    <?php break; ?>
                <?php case (3): ?>
                    <a href="/order/vendor/update-status/<?php echo e($order->id); ?>" class="btn btn-success fw-bold w-50 mx-auto">Finish Cooking</a>
                    <?php break; ?>
                <?php case (4): ?>
                    <div class="fw-bold text-center">Waiting for customer pickup...</div>
                    <?php break; ?>
            <?php endswitch; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\Skripsi App\Pocca\resources\views/orderDetails.blade.php ENDPATH**/ ?>