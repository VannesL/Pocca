

<?php $__env->startPush('custom-js'); ?>
  <script src="https://code.jquery.com/jquery-3.6.4.js" integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E=" crossorigin="anonymous"></script>
  <script type="text/javascript" src="<?php echo e(asset ('js/inputNumberWithButton.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container position-relative">
        
        <div class="container mb-4 text-light rounded" style="background-image: url(<?php echo e(asset('storage/profiles/'.$vendor->image)); ?>); background-size: cover;">
            <div class="row rounded p-3" style="background-color: rgba(0, 0, 0, 0.603); backdrop-filter: blur(1px);">
                <div class="col-10">
                    <div class="row"> <h4><?php echo e($vendor->name); ?></h4></div>
                    <div class="row"> <p><?php echo e($vendor->description); ?></p></div>
                    <div class="row "> 
                        <div class="col-3"><i class="fa-solid fa-star"></i>1</div>
                        <div class="col-9 ">Rp 10-30k</div>
                    </div>
                </div>
                <div class="col-2 align-self-center text-center">
                    <i class="fa fa-heart fa-2xl"></i>
                </div>
            </div>
        </div>
        <form action="<?php echo e(url('/vendor',$vendor->id)); ?>" method="get" class="form-loading mb-3">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-10 ">
                    <div class="form-group <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <input name="search" type="text" value="<?php echo e($search); ?>" class="form-control"
                            placeholder="Search">
                        <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="form-text m-b-none text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-2 ps-1">
                    <button type="submit" class="btn btn-primary btn-block btn_submit text"><i
                            class="fa fa-search"></i></button>
                </div>
            </div>
            </div>
        </form>
        <div class="row px-3">
            <?php if(!$categories->isEmpty()): ?>
                <?php $__currentLoopData = $menuByCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accordion accordion-flush mb-4" id="accordion<?php echo e($loop->index); ?>">
                        <div class="accordion-item ">
                            <h2 class="accordion-header">
                            <button class="accordion-button fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo e($categories[$loop->index]->category_name); ?>" aria-expanded="true" aria-controls="collapseOne">
                                <?php echo e($categories[$loop->index]->category_name); ?>

                            </button>
                            </h2>
                            <div id="<?php echo e($categories[$loop->index]->category_name); ?>" class="accordion-collapse collapse show " data-bs-parent="#accordion<?php echo e($loop->index); ?>">
                                <div class="accordion-body row">
                                    <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        $itemName = explode('_',$item->name)
                                        ?>
                                        <?php if($loop->index%2 ==0): ?>
                                            <div class="col-md-4">
                                                <div class="row h-100">

                                        <?php endif; ?>
                                       
                                        <div class="col-6 p-1">
                                            <?php if($item->availability): ?>
                                            <a class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#<?php echo e($item->id); ?>addToCart" href="">
                                            <?php endif; ?>
                                                <div class="card  text-center h-100 border-white <?php echo e($item->availability? '' : 'opacity-25'); ?>" style="box-shadow: 0px 2px 10px 2px #8b9ce936;">
                                                    <?php if($item->recommended): ?>
                                                    <span class="z-2 d-flex position-absolute translate-middle badge rounded-pill bg-warning text-center align-items-center" style="width:30px; height:30px; left:95%; top:5%;vertical-align: middle">
                                                        <i class="fa-solid fa-thumbs-up fa-lg" style="color: #ffffff;"></i>
                                                    </span>
                                                    <?php endif; ?>
                                                    <?php if($item->image != ''): ?>
                                                        <img src="<?php echo e(asset('storage/menus/'.$item->image)); ?>" class="card-img-top img-thumbnail p-2 border-0 <?php if(!$item->availability): ?> opacity-50 <?php endif; ?>" alt="image error" style="height: 120px; object-fit:contain;">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('storage/menus/default.jpg')); ?>" class="card-img-top img-thumbnail p-2 border-0 <?php if(!$item->availability): ?> opacity-50 <?php endif; ?>" alt="image error" style="height: 120px; object-fit:contain;">
                                                    <?php endif; ?>
                                                    <div class="card-body">
                                                        <div class="row h-75">
                                                            <h6 class="card-title "><?php echo e($itemName[1]); ?></h6>
                                                        </div>
                                                        <div class="row h-25">
                                                            <p class="card-text">Rp <?php echo e($item->price); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php if($item->availability): ?>
                                            </a>    
                                            <!-- Modal -->
                                            <div class="modal fade" id="<?php echo e($item->id); ?>addToCart" tabindex="-1" role="dialog" aria-hidden="true">
                                                <div class="modal-dialog modal-lg  position-absolute w-100  mb-0 ms-0  bottom-0 start-50 translate-middle-x" style="max-height: 90%" role="document">
                                                    
                                                    <div class="modal-content" style="">
                                                        <div class="modal-header">
                                                                <?php if($item->image != ''): ?>
                                                                    <img src="<?php echo e(asset('storage/menus/'.$item->image)); ?>" class="card-img-top img-thumbnail p-2 border-0 <?php if(!$item->availability): ?> opacity-50 <?php endif; ?>" alt="image error" style="" >
                                                                <?php else: ?>
                                                                    <img src="<?php echo e(asset('storage/menus/default.jpg')); ?>" class="card-img-top img-thumbnail p-2 border-0 <?php if(!$item->availability): ?> opacity-50 <?php endif; ?>" alt="image error" style="" >
                                                                <?php endif; ?>
                                                          </div>
                                                    
                                                    <div class="modal-body">     
                                                        <div class="row px-2">
                                                            <div class="col-9">
                                                                <h5 class=""><?php echo e($itemName[1]); ?></h5>
                                                                
                                                            </div>
                                                            <div class="col-3 text-end"> 
                                                                <p><i class="fa-light fa-timer"></i> <?php echo e($item->cook_time); ?>  <span class="fw-medium">min</span></p>
                                                                
                                                            </div>
                                                        </div>
                                                        <div class="row px-3"> 
                                                            <p><?php echo e($item->description); ?></p>
                                                        </div>
                                                        <div class="row px-3">
                                                            <form action="<?php echo e(url('/vendor/'.$vendor->id.'/addToCart/'.$item->id)); ?>" method="post" class="form-loading mb-3">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="mb-3">
                                                                    <label for="notes" class="form-label" >Notes</label>
                                                                    <textarea class="form-control" id="notes" name='notes' rows="3" placeholder="notes"></textarea>
                                                                </div>
                                                                <div class="row mb-4">
                                                                    <div class="col-6">
                                                                        Rp <?php echo e($item->price); ?>

                                                                    </div>
                                                                    <div class="col-6">
                                                                        <div class="input-group inline-group">
                                                                            <div class="input-group-prepend">
                                                                              <a class="btn btn-outline-light btn-minus btn-danger">
                                                                                <i class="fa fa-minus"></i>
                                                                              </a>
                                                                            </div>
                                                                            <input class="form-control quantity" min="0" name="quantity" value="1" type="number">
                                                                            <div class="input-group-append">
                                                                              <a class="btn btn-outline-light btn-plus btn-success">
                                                                                <i class="fa fa-plus"></i>
                                                                              </a>
                                                                            </div>
                                                                          </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <button class="btn btn-primary w-50 mx-auto" type="submit">Add Item</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                    
                                                    </div>
                                                </div>
                                            </div>     
                                            <?php endif; ?>
                                            </a>           
                                        </div>
                                        
                                        <?php if($loop->index%2 !=0 || $loop->last): ?>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div> 
                    </div>            
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            <?php else: ?>
            <h3 class="col p-5 text-center">Sorry we do not found the menu in this vendor.</h3>    
            <?php endif; ?>
        </div>

    </div>

    <?php if($cartCount>0): ?>    
        <div class="addBtn text-center position-fixed z-3" style="bottom:20px; right:30px;">
            <a href="<?php echo e(url('/customer-cart')); ?>" class="btn rounded btn-primary p-3">
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    <?php echo e($cartCount); ?>

                    <span class="visually-hidden">unread messages</span>
                </span>
                <i class="fa-solid fa-cart-shopping"></i>
            </a>
        </div>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\Skripsi App\Pocca\resources\views/customerMenu.blade.php ENDPATH**/ ?>