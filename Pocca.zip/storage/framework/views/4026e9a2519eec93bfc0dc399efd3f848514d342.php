

<?php $__env->startPush('custom-js'); ?>
    <script src="https://code.jquery.com/jquery-3.6.4.js" integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E=" crossorigin="anonymous"></script>
    <script type="text/javascript" src="<?php echo e(asset ('js/imagePreviews.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset ('js/refreshOrderDetails.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h6><?php echo e($order->vendor->canteen->name); ?></h6>
        <h3 class=""><?php echo e($order->vendor->store_name); ?></h3>
        <h6 class="mb-3"><?php echo e($order->vendor->phone_number); ?></h6>

        <?php
            $color = "";

            switch ($order->status->id) {
            case 1:
                $color = "warning";
                break;
            case 2:
                $color = "secondary";
                break;
            case 3:
                $color = "primary";
                break;
            case 4:
                $color = "success";
                break;
            case 5:
                $color = "dark";
                break;
            case 6:
                $color = "danger";
                break;
            }
        ?>
        <div class="d-flex justify-content-between mb-2">
            <div id="customerOrderStatus" class="text-bg-<?php echo e($color); ?> text-center fs-3 fw-bold px-2">
                <?php echo e($order->status->name); ?>

            </div> 
            <div>
                <?php if($order->type): ?>
                    <div class="mt-2">Eat-In</div>
                <?php else: ?>
                    <div class="mt-2">Takeout</div>
                <?php endif; ?>   
            </div>
        </div>
            

        <div class="container p-2 border border-dark bg-light">
            <div class="header d-flex justify-content-between px-2 pt-2">
                <div>OrderId: <?php echo e($order->id); ?></div>
                <div class="align-items-end"><?php echo e($order->date); ?></div>
            </div>
            <hr>
            <table class="table table-borderless">
                <tbody>
                    <?php $__currentLoopData = $orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $itemName = explode('_',$orderItem->menu->name);
                        $price = $orderItem->quantity * $orderItem->menu->price;
                    ?>
                    <tr class="border-end-0">
                        <td class="col-md-1"><?php echo e($orderItem->quantity); ?>x</td>
                        <td class="col-md-9"><?php echo e($itemName[1]); ?></td>
                        <td class="col-md-2">Rp. <?php echo e($price); ?></td>
                    </tr>
                    <?php if($orderItem->notes != ''): ?>
                        <tr>
                            <td class="col-md-1"></td>
                            <td class="col-md-9 fst-italic pt-0"><?php echo e($orderItem->notes); ?></td>
                        </tr>
                    <?php endif; ?>              
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <hr>
            <div class="footer d-flex justify-content-between px-2">
                <div>Total:</div>
                <div class="h4">Rp. <?php echo e($order->total); ?></div>
            </div>
        </div>

        <div class=" container d-flex my-3 h-100 flex-column">
            <?php if($order->payment_image != ''): ?>
                <img id = "paymentImg" src="<?php echo e(asset('storage/payments/'.$order->payment_image)); ?>" class="img-thumbnail border-0 mb-4 w-100" alt="image error" style="height: 250px; object-fit:contain;" data-bs-toggle="modal" data-bs-target="#imgPreview">
            <?php endif; ?>

            <?php switch($order->status->id):
                case (1): ?>
                    <div class="fw-bold text-center mt-3">Waiting for vendor confirmation...</div>
                    <?php break; ?>
                <?php case (2): ?>
                    <?php if($order->payment_image == ''): ?>
                        <form method="POST" action="<?php echo e(url('/order/customer/payment/'.$order->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                            <img src="<?php echo e(asset('storage/qris/'.$order->vendor->qris)); ?>" alt="qris not found" class="img-thumbnail border-0 mb-4 w-100" style="height: 300px; object-fit:contain;" data-bs-toggle="modal" data-bs-target="#imgPreview">
    
                            <div class="form-outline mb-4">
                                <label for="image" class="h5 fw-bold">Proof of Payment</label>
                                <input class="image form-control form-control-sm <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="image" name="image" type="file" accept="image/*">
    
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
    
                            <img id="preview-image" src="<?php echo e(asset('storage/payments/no-image.jpg')); ?>" alt="" class="img-thumbnail border-0 mb-4 w-100" style="height: 300px; object-fit:contain;">
                            
                            <button class="btn btn-primary w-100 col m-2 fw-bold" type="submit">Submit Payment</button>   
                        </form>  
                    <?php else: ?>
                        <div id="payed" class="fw-bold text-center mt-3">Waiting for vendor verification...</div>
                    <?php endif; ?>
                    <?php break; ?>
                <?php case (3): ?>
                    <button href="/order/update-status/<?php echo e($order->id); ?>" class="btn btn-outline-dark fw-bold w-50 mx-auto" disabled>I got my order!</button>
                    <?php break; ?>
                <?php case (4): ?>
                    <a href="/order/update-status/<?php echo e($order->id); ?>" class="btn btn-success fw-bold w-50 mx-auto" >I got my order!</a>
                    <?php break; ?>
                <?php case (5): ?>
                    <?php if($order->reviewed == false): ?>
                        <a class="btn btn-white border-dark fw-bold w-50 mx-auto"  data-bs-toggle="modal" data-bs-target="#reviewForm" <?php if($order->reviewed): ?> disabled <?php endif; ?>>Leave a Review</a>
                    <?php endif; ?>
                    <?php break; ?>
                <?php case (6): ?>
                    <form>
                        <fieldset disabled>
                            <div class="mb-3">
                            <label for="disabledTextInput" class="form-label fw-bold">Rejected for:</label>
                            <input type="text" id="disabledTextInput" class="form-control" placeholder="<?php echo e($order->rejection_reason); ?>">
                            </div>
                        </fieldset>
                    </form>
                <?php break; ?>
            <?php endswitch; ?>

            <!-- Modal -->
            <div class="modal fade bg-transparent" id="imgPreview" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered bg-transparent" style="" role="document">
                    <div class="modal-body bg-transparent">
                        <?php if($order->status_id != 2): ?> 
                            <img src="<?php echo e(asset('storage/payments/'.$order->payment_image)); ?>" class="img-thumbnail border-0 mb-4 w-100 h-100" alt="image error" style="object-fit:contain;">
                        <?php else: ?>
                            <img src="<?php echo e(asset('storage/qris/'.$order->vendor->qris)); ?>" class="img-thumbnail border-0 mb-4 w-100 h-100" alt="image error" style="object-fit:contain;">
                        <?php endif; ?>
                       
                    </div>
                </div> 
            </div>

            <div class="modal fade bg-transparent" id="reviewForm" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered bg-transparent" style="" role="document">
                    <form method="POST" action="/review/<?php echo e($order->id); ?>" class="modal-content" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header">
                            <h5 class="modal-title" id="reviewTitle">Write a Review!</h5>
                            <button type="button" class="btn btn-outline-transparent" data-bs-dismiss="modal">
                                <i class="fa fa-times fa-lg" style="color: #f70808;"></i>
                            </button> 
                        </div>
                        <div class="modal-body d-flex justify-content-center flex-column">
                            <div class="rate d-flex justify-content-center mb-3 flex-row-reverse">
                                <input type="radio" id="star5" class="rate" name="rating" value="5" checked/>
                                <label for="star5" title="text">5 stars</label>
                                <input type="radio" id="star4" class="rate" name="rating" value="4"/>
                                <label for="star4" title="text">4 stars</label>
                                <input type="radio" id="star3" class="rate" name="rating" value="3"/>
                                <label for="star3" title="text">3 stars</label>
                                <input type="radio" id="star2" class="rate" name="rating" value="2">
                                <label for="star2" title="text">2 stars</label>
                                <input type="radio" id="star1" class="rate" name="rating" value="1"/>
                                <label for="star1" title="text">1 star</label>
                            </div>

                            <div class="form-outline">
                                <label id="reviewDesc" for="description" class="h6 fw-bold">Comments</label>
                                <textarea id="description" type="textbox" class="form-control form-control-md" name="description" placeholder="ex. Great food!" rows="3" style="resize:none;"></textarea>
                            </div>

                            <div class="form-outline my-4">
                                <label id="imgLabel" for="reviewImg" class="h6 fw-bold">Review Images</label>
                                <input class="reviewImg form-control form-control-sm <?php $__errorArgs = ['reviewImg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="reviewImg" name="reviewImg[]" type="file" accept="image/*" multiple>
            
                                <?php $__errorArgs = ['reviewImg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="container-fluid">
                                <div id="images" class="overflow-scroll row flex-row flex-nowrap">
                                    <img id="preview-image" src="<?php echo e(asset('storage/payments/no-image.jpg')); ?>" alt="" class="img-thumbnail border-0 mb-4 w-100" style="height: 300px; object-fit:contain;">
                                </div>
                            </div>
                                
                            
                        </div>
                        <input name="vendorid" type="hidden" value="<?php echo e($order->vendor->id); ?>">
                        <div class="modal-footer d-flex justify-content-around">  
                            <button type ="submit" class="btn btn-primary col">
                                Submit
                            </button>
                        </div>
                    </form>
                </div> 
            </div>
        </div>
    </div>

    <link rel="stylesheet" href="<?php echo e(asset ('css/customerDetail.css')); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\Skripsi App\Pocca\resources\views/customerOrderDetails.blade.php ENDPATH**/ ?>