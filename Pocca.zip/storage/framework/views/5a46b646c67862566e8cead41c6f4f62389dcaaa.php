

<?php $__env->startPush('custom-js'); ?>
    <script src="https://code.jquery.com/jquery-3.6.4.js" integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E=" crossorigin="anonymous"></script>
    <script type="text/javascript" src="<?php echo e(asset ('js/updateOrderPage.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>    
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="mb-0">Current Orders</h3>
            <a class="text-decoration-none text-reset" data-bs-toggle="modal" data-bs-target="#infoModal"><i class="fa-solid fa-circle-info fa-lg"></i></a>
        </div>
        
        <?php
            $guard = "vendor";
            $updateArr = array();
            $orderArr = array();
            $totalOrders = $orders->count();
        ?>

        <div class="row">
            <?php if(!$orders->isEmpty()): ?>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $updateTime = \Carbon\Carbon::parse($order->updated_at)->format('Y-m-d-H-i-s');
                        array_push($updateArr, $updateTime);
                        array_push($orderArr, $order->id);
                    ?>
                    <?php if($order->status_id == 1): ?>  
                        <a id="<?php echo e($loop->index); ?>" href="/order/<?php echo e($order->id); ?>" class="text-decoration-none text-dark"> 
                            <div class="card mb-3 text-bg-light border-danger border-3 border-bg" style="box-shadow: 0px 2px 10px 2px #8b9ce956;">
                                <span class="position-absolute top-100 start-50 translate-middle badge rounded-pill bg-danger">
                                    NEW
                                </span>
                                <div class="card-body">
                                    <h5 class="card-title fw-bold">Order for: <?php echo e($order->customer->name); ?></h5>
                                    <div class="row card-text w-100">
                                        <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $itemName = explode('_',$orderItem->menu->name)
                                            ?>
                                            <div class="col-2"><?php echo e($orderItem->quantity); ?>x</div>
                                            <?php if($orderItem->notes != ''): ?>
                                                <div class="col-9">
                                                    <div><?php echo e($itemName[1]); ?></div>
                                                    <div class="fst-italic"><?php echo e($orderItem->notes); ?></div>
                                                </div>
                                            <?php else: ?>
                                                <div class="col-9"><?php echo e($itemName[1]); ?></div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($order->type): ?>
                                            <div class="mt-2">Type: Eat-In</div>
                                        <?php else: ?>
                                            <div class="mt-2">Type: Takeout</div>
                                        <?php endif; ?>   
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($order->status_id != 1): ?>
                        <a href="/order/<?php echo e($order->id); ?>" class="text-decoration-none">
                            <div class="card mb-3 text-bg-light border-light" style="box-shadow: 0px 2px 10px 2px #8b9ce956;">
                                <div class="card-body">
                                    <h5 class="card-title fw-bold">Order for: <?php echo e($order->customer->name); ?></h5>
                                    <div class="row card-text w-100">
                                        <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $itemName = explode('_',$orderItem->menu->name)
                                            ?>
                                            <div class="col-2"><?php echo e($orderItem->quantity); ?>x</div>
                                            <?php if($orderItem->notes != ''): ?>
                                                <div class="col-9">
                                                    <div><?php echo e($itemName[1]); ?></div>
                                                    <div class="fst-italic"><?php echo e($orderItem->notes); ?></div>
                                                </div>
                                            <?php else: ?>
                                                <div class="col-9"><?php echo e($itemName[1]); ?></div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($order->type): ?>
                                            <div class="mt-2">Type: Eat-In</div>
                                        <?php else: ?>
                                            <div class="mt-2">Type: Takeout</div>
                                        <?php endif; ?>   
                                    </div>
                                </div>
                                <?php
                                    $color = "";

                                    switch ($order->status_id) {
                                    case 2:
                                        $color = "secondary";
                                        break;
                                    case 3:
                                        $color = "primary";
                                        break;
                                    case 4:
                                        $color = "success";
                                        break;
                                    }
                                ?>
                                <div class="card-footer text-bg-<?php echo e($color); ?> text-center fw-bold">
                                    <?php echo e($order->status->name); ?>

                                </div>
                            </div>
                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="container d-flex align-items-center justify-content-center" style="height: 50vh">
                    <h2 class="text-center text-wrap">There are no orders yet, check again later!</h2>
                </div>
                
            <?php endif; ?>

            <!-- Modal -->
            <div class="modal fade" id="infoModal" tabindex="-1" role="dialog" aria-labelledby="infoModalLabel" aria-hidden="true">
                <div class="modal-dialog pt-2" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="infoModalLabel">Types of Order Status!</h5>
                            <a data-bs-dismiss="modal" class="">
                                <i class="fa fa-times fa-lg" style="color: #f70808;"></i>
                            </a>
                        </div>
                        <div class="modal-body">
                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $color = "";

                                    switch ($status->id) {
                                    case 1:
                                        $color = "warning";
                                        break;
                                    case 2:
                                        $color = "secondary";
                                        break;
                                    case 3:
                                        $color = "primary";
                                        break;
                                    case 4:
                                        $color = "success";
                                        break;
                                    case 5:
                                        $color = "dark";
                                        break;
                                    case 6:
                                        $color = "danger";
                                        break;
                                    }
                                ?>
                                <div class="mb-2">
                                    <div id="orderStatus" class="text-bg-<?php echo e($color); ?> text-center fs-4 fw-bold px-2 py-1">
                                        <?php echo e($status->name); ?>

                                    </div> 
                                    <h6 class="px-2 mt-2 mb-4"><?php echo e($status->description); ?></h6>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>

            <script>
                var guard = <?php echo json_encode($guard, 15, 512) ?>;
                var updateArr = <?php echo json_encode($updateArr, 15, 512) ?>;
                var orderArr = <?php echo json_encode($orderArr, 15, 512) ?>;
                var totalOrders = <?php echo json_encode($totalOrders, 15, 512) ?>;
            </script>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\Skripsi App\Pocca\resources\views/vendorOrder.blade.php ENDPATH**/ ?>