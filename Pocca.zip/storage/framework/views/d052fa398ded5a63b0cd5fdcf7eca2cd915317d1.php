


<?php $__env->startSection('content'); ?>
<?php if(auth()->guard("vendor")->user()->upcoming_deletion_date != null): ?>
    <div><?php echo e(auth()->guard("vendor")->user()->rejection_reason); ?></div>
<?php elseif(auth()->guard("vendor")->user()->approved_by == null): ?>
    <div>Please wait for account verification</div>
<?php else: ?>
<div class="container-fluid  px-4">
    <div class="col">
        <div class="row"> 
            <div class="col-md-4  mb-3">
                <div class="card bg-warning ">
                    <a class="text-white text-decoration-none" href="#">
                        <div class="card-body p-3">
                            <h5 class="mb-3" style="font-size: 15px">Rating</h5>
                            <h2 class="mb-3 text-break fw-bold" style="font-size: 18px">
                                <i class="fa-solid fa-star"></i>
                                5
                            </h2>
                            <h6 class="card-text font-weight-light" style="font-size: 12px">See review 
                                <i class="fa-solid fa-angle-right" style="color: #ffffff;"></i>
                            </h6>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-8">
                <div class="row">
                    <div class="col-6 mb-3">
                        <div class="card  bg-success h-100">
                            <div class="card-body text-light p-3">
                                <h5 class="mb-3" style="font-size: 15px">This Month Revenue</h5>
                                <h2 class="mb-3 text-break fw-bold" style="font-size: 18px">
                                    RP <?php echo e($revenueOrders[0]->revenue); ?>

                                </h2>
                                <?php if($revDiff >=0): ?>
                                <h6 class="card-text font-weight-light" style="font-size: 12px" > Increase by <?php echo e($revDiff); ?>%</h6>
                                <?php else: ?>
                                <h6 class="card-text font-weight-light" style="font-size: 12px">Decrease by <?php echo e($revDiff); ?>%</h6>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-6 mb-3">
                        <div class="card  bg-info h-100">
                            <div class="card-body text-light p-3">
                                <h5 class="mb-3" style="font-size: 15px">This Month Orders</h5>
                                <h2 class="mb-3 text-break fw-bold" style="font-size: 18px">
                                    <i class="fa-solid fa-cart-shopping"></i> <?php echo e($revenueOrders[0]->total_order); ?>

                                </h2>
                                <?php if($ordDiff >=0): ?>
                                <h6 class="card-text font-weight-light " style="font-size: 12px"> Increase by <?php echo e($ordDiff); ?>% </h6>
                                <?php else: ?>
                                <h6 class="card-text font-weight-light" style="font-size: 12px">Decrease by <?php echo e($ordDiff); ?>%</h6>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row px-2"> 
            <h2 class="text-center mb-3">Sales Report</h2>
            <form action="<?php echo e(url('/vendor-home')); ?>" method="GET" class="form-loading mb-3" style="padding: 0">
                <?php echo csrf_field(); ?>
                <div class="row ">
                    <div class="col-10" >
                        <div class="form-group <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <input name="selectedDate"  id="selectedDate" type="date" value="<?php echo e($selectedDate); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="col-2 ps-1 ">
                        <button type="submit" class="btn btn-primary btn-block btn_submit ms-0"><i
                                class="fa fa-search"></i></button>
                    </div>
                </div>
            </form>
            <table class="table table-striped table-bordered " style="">
                <thead>
                  <tr>
                    <th class="col-1 text-center"scope="col">#</th>
                    <th class="col-6" scope="col">Menu</th>
                    <th class="col text-center" scope="col">Sold</th>
                    <th class="col-4 text-end"scope="col">Profits</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $menuName = explode('_',$menu->name)
                        ?>
                        <tr>
                            <th class="text-center" scope="row"><?php echo e($loop->iteration); ?></th>
                            <td class="text-break"><?php echo e($menuName[1]); ?></td>
                            <td class="text-break text-center"><?php echo e($menu->sold); ?></td>
                            <td class="text-end">Rp <?php echo e($menu->profits); ?></td>
                        </tr>
                       
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td  class="text-center fw-bold" colspan="3">Total Profits</td>
                    <td class="text-end fw-bold">Rp <?php echo e($totalProfits); ?></td>
                  </tr>
                </tbody>
              </table>
              
              
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\Skripsi App\Pocca\resources\views/vendorSalesReport.blade.php ENDPATH**/ ?>