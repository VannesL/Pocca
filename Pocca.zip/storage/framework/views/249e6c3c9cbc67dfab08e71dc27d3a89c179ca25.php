



<?php $__env->startSection('content'); ?>
    <div class="container">
        <h6><?php echo e($order->vendor->canteen->name); ?></h6>
        <h3 class=""><?php echo e($order->vendor->store_name); ?></h3>
        <h6 class="mb-3"><?php echo e($order->customer->phone_number); ?></h6>

        <?php
            $color = "";

            switch ($order->status->id) {
            case 1:
                $color = "warning";
                break;
            case 2:
                $color = "secondary";
                break;
            case 3:
                $color = "primary";
                break;
            case 4:
                $color = "success";
                break;
            case 5:
                $color = "dark";
                break;
            }
        ?>
        <div class="d-flex justify-content-between mb-2">
            <div id="orderStatus" class="text-bg-<?php echo e($color); ?> text-center fs-3 fw-bold px-2">
                <?php echo e($order->status->name); ?>

            </div> 
            <div>
                <?php if($order->type): ?>
                    <div class="mt-2">Eat-In</div>
                <?php else: ?>
                    <div class="mt-2">Takeout</div>
                <?php endif; ?>   
            </div>
        </div>
            

        <div class="container p-2 border border-dark bg-light">
            <div class="header d-flex justify-content-between px-2 pt-2">
                <div>OrderId: <?php echo e($order->id); ?></div>
                <div class="align-items-end"><?php echo e($order->date); ?></div>
            </div>
            <hr>
            <table class="table table-borderless">
                <tbody>
                    <?php $__currentLoopData = $orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $itemName = explode('_',$orderItem->menu->name);
                        $price = $orderItem->quantity * $orderItem->menu->price;
                    ?>
                    <tr class="border-end-0">
                        <td class="col-md-1"><?php echo e($orderItem->quantity); ?>x</td>
                        <td class="col-md-9"><?php echo e($itemName[1]); ?></td>
                        <td class="col-md-2">Rp. <?php echo e($price); ?></td>
                    </tr>
                    <?php if($orderItem->notes != ''): ?>
                        <tr>
                            <td class="col-md-1"></td>
                            <td class="col-md-9 fst-italic pt-0"><?php echo e($orderItem->notes); ?></td>
                        </tr>
                    <?php endif; ?>              
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <hr>
            <div class="footer d-flex justify-content-between px-2">
                <div>Total:</div>
                <div class="h4">Rp. <?php echo e($order->total); ?></div>
            </div>
        </div>

        <div class=" container d-flex my-3 h-100 flex-column">
            <form class="form-horizontal" action="" id="addStar" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group required">
                <div class="col-sm-12">
                    <input class="star star-5" value="5" id="star-5" type="radio" name="star"/>
                    <label class="star star-5" for="star-5"></label>
                    <input class="star star-4" value="4" id="star-4" type="radio" name="star"/>
                    <label class="star star-4" for="star-4"></label>
                    <input class="star star-3" value="3" id="star-3" type="radio" name="star"/>
                    <label class="star star-3" for="star-3"></label>
                    <input class="star star-2" value="2" id="star-2" type="radio" name="star"/>
                    <label class="star star-2" for="star-2"></label>
                    <input class="star star-1" value="1" id="star-1" type="radio" name="star"/>
                    <label class="star star-1" for="star-1"></label>
                    </div>
                </div>
            

                <div class="form-outline mb-4">
                    <label for="proof" class="h5 fw-bold">Review Images (jpg,bmp,png)</label>
                    <input class="proof form-control form-control-sm <?php $__errorArgs = ['proof'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="proof" name="proof" type="file">

                    <?php $__errorArgs = ['proof'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </form>

            <img id="preview-image" src="<?php echo e(asset('storage/payments/no-image.jpg')); ?>" alt="" class="img-thumbnail border-0 mb-4 w-100" style="height: 300px; object-fit:contain;">
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
 
    <script type="text/javascript">    
        function readURL(input) {
            if (input.files && input.files[0] && input.files[0].type) {
                var reader = new FileReader();
                
                reader.onload = function (e) {
                    $('#preview-image').attr('src', e.target.result);
                }
                
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        $("#proof").change(function(){
            readURL(this);
        });

        $('#addStar').change('.star', function(e) {
            $(this).submit();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\Skripsi App\Pocca\resources\views/reviewForm.blade.php ENDPATH**/ ?>