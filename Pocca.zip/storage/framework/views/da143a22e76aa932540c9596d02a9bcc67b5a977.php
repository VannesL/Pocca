

<?php $__env->startSection('content'); ?>    
    <div class="container">
        <h3>Order History</h3>
        <div class="row">
            <?php if(!$orders->isEmpty()): ?>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/order/<?php echo e($order->id); ?>" class="text-decoration-none">
                    <div class="card mb-3 text-bg-light border-light" style="box-shadow: 0px 2px 10px 2px #8b9ce956;">
                        <div class="card-body">
                            <h5 class="card-title fw-bold">Order for: <?php echo e($order->customer->name); ?></h5>
                            <div class="row card-text w-100">
                                <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $itemName = explode('_',$orderItem->menu->name)
                                    ?>
                                    <div class="col-2"><?php echo e($orderItem->quantity); ?>x</div>
                                    <?php if($orderItem->notes != ''): ?>
                                        <div class="col-9">
                                            <div><?php echo e($itemName[1]); ?></div>
                                            <div class="fst-italic"><?php echo e($orderItem->notes); ?></div>
                                        </div>
                                    <?php else: ?>
                                        <div class="col-9"><?php echo e($itemName[1]); ?></div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="d-flex justify-content-between align-items-center mt-4">
                                <?php if($order->type): ?>
                                    <div class="">Type: Eat-In</div>
                                <?php else: ?>
                                    <div class="">Type: Takeout</div>
                                <?php endif; ?> 
                                <div class=""><?php echo e($order->date); ?></div>
                            </div>
                        </div>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="container d-flex align-items-center justify-content-center" style="height: 50vh">
                    <h2 class="text-center text-wrap">There are no orders yet, check again later!</h2>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\Skripsi App\Pocca\resources\views/vendorOrderHistory.blade.php ENDPATH**/ ?>