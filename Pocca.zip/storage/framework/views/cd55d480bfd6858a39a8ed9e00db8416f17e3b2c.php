

<?php $__env->startPush('custom-js'); ?>
  <script src="https://code.jquery.com/jquery-3.6.4.js" integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E=" crossorigin="anonymous"></script>
  <script type="text/javascript" src="<?php echo e(asset ('js/inputNumberWithButton.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(!is_null($cart)): ?>    
        <div class="container">
            <div class="d-flex justify-content-between mb-2">
                <div id="orderStatus" class="align-self-end">
                    <h6><?php echo e($cart->vendor->canteen->name); ?></h6>
                    <h3 class=""><?php echo e($cart->vendor->store_name); ?></h3>
                    <h6 class="mb-0"><?php echo e($cart->vendor->phone_number); ?></h6>         
                </div> 
                <div class="align-self-end fw-medium">
                    <?php echo e($cart->updated_at->toDateString()); ?>

                </div>
            </div>
            <div class="container p-2 border border-dark bg-light mb-3">
                <div class="header text-center px-2 pt-2">
                    <h4>Cart Summary</h4>
                </div>
                <hr>
                <table class="table table-borderless">
                    <tbody>
                        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $itemName = explode('_',$cartItem->menu->name);
                            $price = $cartItem->quantity * $cartItem->menu->price;
                        ?>
                        <tr class="border-end-0" data-bs-toggle="modal" data-bs-target="#<?php echo e($cartItem->menu->id); ?>addToCart">
                            <td class="col-1"><?php echo e($cartItem->quantity); ?>x</td>
                            <td class="col-6"><?php echo e($itemName[1]); ?></td>
                            <td class="col-4"><?php echo e(rupiah($price ?? '',true)); ?></td>
                            <td class="col-1"><i class="fa-solid fa-pen-to-square"></i></button></td>
                        </tr>
                            
                        <?php if($cartItem->notes != ''): ?>
                            <tr data-bs-toggle="modal" data-bs-target="#<?php echo e($cartItem->menu->id); ?>addToCart">
                                <td class="col-md-1"></td>
                                <td class="col-md-11 fst-italic pt-0"><?php echo e($cartItem->notes); ?></td>
                            </tr>
                        <?php endif; ?>     

                        <!-- Modal -->
                        <div class="modal fade" id="<?php echo e($cartItem->menu->id); ?>addToCart" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class=" z-3 modal-dialog position-absolute  mb-0 start-0 end-0 bottom-0" style="max-height: 90%" role="document">
                                
                                <div class="modal-content" style="">
                                    <div class="container">
                                        <div class="row">
                                            <a class="btn btn-plus rounded-0 btn-danger" data-bs-dismiss="modal">
                                                <i class="fa-solid fa-times"></i>
                                            </a>
                                        </div>
                                    </div>

                                    <div class="modal-header">
                                        <?php if($cartItem->menu->image != ''): ?>
                                            <img src="<?php echo e(asset('storage/menus/'.$cartItem->menu->image)); ?>" class="card-img-top img-thumbnail p-2 border-0 <?php if(!$cartItem->menu->availability): ?> opacity-50 <?php endif; ?>" alt="image error" style="" >
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('storage/menus/default.jpg')); ?>" class="card-img-top img-thumbnail p-2 border-0 <?php if(!$cartItem->menu->availability): ?> opacity-50 <?php endif; ?>" alt="image error" style="" >
                                        <?php endif; ?>
                                    </div>
                                
                                    <div class="modal-body">     
                                        <div class="row px-2">
                                            <div class="col-8">
                                                <h5 class="text-break"><?php echo e($itemName[1]); ?></h5>
                                                
                                            </div>
                                            <div class="col-4 text-end fw-medium"> 
                                                <p> <i class="fa-solid fa-hourglass-end me-1"></i> <?php echo e($cartItem->menu->cook_time); ?>  <span class="">min</span></p>
                                                
                                            </div>
                                        </div>
                                        <div class="row px-3"> 
                                            <p><?php echo e($cartItem->menu->description); ?></p>
                                        </div>
                                        <div class="row px-3 d-flex align-items-center flex-column">
                                            <form action="<?php echo e(url('/update-cart/'.$cartItem->id)); ?>" method="post" class="form-loading mb-3">
                                                <?php echo csrf_field(); ?>
                                                <div class="mb-3">
                                                    <label for="notes" class="form-label fw-medium" >Notes</label>
                                                    <textarea class="form-control" id="notes" name='notes' rows="3" placeholder="ex. Make it good!"><?php echo e($cartItem->notes); ?></textarea>
                                                </div>
                                                <div class="row mb-4 d-flex align-items-center">
                                                    <div class="col-6 fw-medium h4 mb-0">
                                                        <?php echo e(rupiah($cartItem->menu->price ?? '',true)); ?>

                                                    </div>
                                                    <div class="col-6">
                                                        <div class="input-group inline-group">
                                                            <div class="input-group-prepend">
                                                            <a class="btn btn-minus rounded-0 btn-secondary">
                                                                <i class="fa fa-minus"></i>
                                                            </a>
                                                            </div>
                                                            <input class="form-control quantity" min="1" name="quantity" value="<?php echo e($cartItem->quantity); ?>" type="number">
                                                            <div class="input-group-append">
                                                            <a class="btn btn-plus rounded-0 btn-secondary">
                                                                <i class="fa fa-plus"></i>
                                                            </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <?php if($cartItem): ?>
                                                        <div class="d-flex justify-content-around">
                                                            <a href="<?php echo e(url('/remove-item/'.$cartItem->id)); ?>" class="btn btn-danger w-50 me-1">Remove Item</a>
                                                            <button class="btn btn-primary w-50 ms-1" type="submit">Update Item</button>
                                                        </div>
                                                    <?php else: ?>
                                                        <button class="btn btn-primary w-100" type="submit">Save Changes</button>
                                                    <?php endif; ?>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>          
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="4" class="text-center">
                                <a class="text-decoration-none fw-medium btn btn-outline-dark mt-2 w-100" href="<?php echo e(url('/vendor/'.$cart->vendor->id)); ?>">
                                    Add More <i class="fa-solid fa-plus"></i>
                                </a>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <hr>
                <div class="footer d-flex justify-content-between px-2">
                    <div>Total:</div>
                    <div class="h4"><?php echo e(rupiah($cart->total ?? '',true)); ?></div>
                </div>
            </div>
            <form action="<?php echo e(url('/checkout')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="mb-5">
                    <select class="form-select form-select-sm" name='type'aria-label="Default select example">
                        <option selected value='1'>Eat-In</option>
                        <option value="0">Takeout</option>
                    </select>
                </div>
                <button class="btn rounded btn-primary w-100 ms-1 py-2 fw-medium" type="submit">Confirm Order</button>
            </form>
                
        </div>
    <?php else: ?>
    <div class="container h-100">

        <h2 class="position-absolute top-50 start-50 translate-middle text-center">Sorry your cart is still emtpy</h2>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\Skripsi App\Pocca\resources\views/Customer/customerCart.blade.php ENDPATH**/ ?>