

<?php $__env->startPush('custom-js'); ?>
  <script type="text/javascript" src="<?php echo e(asset ('js/refreshOrderPage.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>    
    <div class="container">
        <div class="row  mb-5">
            <h3 class="text-center">Reviews</h3>
            <h2 class=" text-center fw-bold" style="font-size: 30px">
                <i class="fa-solid fa-star" style="color: #ffec00;"></i>
                <?php echo e($avgRating); ?>

            </h2>
        </div>
        
                
       
        <div class="container">
            
                <?php if(!$reviews->isEmpty()): ?>
                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mb-3 text-bg-light border-light" style="box-shadow: 0px 2px 10px 2px #8b9ce956;">
                        
                        <div class="card-body">
                            <div class="row">
                                <div class="col-7">
                                    <div class="row">
                                        <p class="mb-0 fw-bold"><?php echo e($review->order->customer->name); ?></p>
                                        
                                    </div>
                                    <div class="row">
                                        <p class="mb-0">
                                            <?php if($review->order->type==0): ?>
                                            Takeout
                                            <?php else: ?>
                                            Eat-In
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-5">
                                    <p class="mb-0 fw-bold text-end"><?php echo e($review->date); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <p>
                                    <?php for($i = 0; $i < $review->rating; $i++): ?>
                                        <i class="fa-solid fa-star" style="color: #ffec00;"></i>
                                    <?php endfor; ?>
                                </p>
                            </div>
                          <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                          <div class="row">
                            <div class="container-fluid" style="">
                                <div id="images" class=" row flex-row flex-nowrap " style="overflow-x:scroll">
                                        <?php $__currentLoopData = $review->reviewImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                            <div class="col"> 
                                                <img id="preview-image" src="<?php echo e(asset('storage/reviewImages/'.$img->path)); ?>" class="border-0 " style=" object-fit:contain; max-height:100px;max-width:150px" alt="nothing">
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                          </div>
                        </div>
                      </div>
                            
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <?php else: ?>
                    <h2 class="mt-4 text-center text-wrap">There are no reviews yet, check again later!</h2>
                <?php endif; ?>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\Skripsi App\Pocca\resources\views/vendorReview.blade.php ENDPATH**/ ?>